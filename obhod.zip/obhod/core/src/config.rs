use crate::parse::Server;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(default)]
pub struct Settings {
    /// Российские домены (.ru, .рф, .su) и локальные адреса идут напрямую
    pub bypass_ru: bool,
    /// "off" | "include" (через VPN только перечисленные) | "exclude" (перечисленные мимо VPN)
    pub split_mode: String,
    pub packages: Vec<String>,
    pub direct_domains: Vec<String>,
    pub proxy_domains: Vec<String>,
    pub remote_dns: String,
    pub mtu: u32,
}

impl Default for Settings {
    fn default() -> Self {
        Self { bypass_ru: true, split_mode: "off".into(), packages: vec![], direct_domains: vec![],
               proxy_domains: vec![], remote_dns: "https://1.1.1.1/dns-query".into(), mtu: 9000 }
    }
}

const RU_SUFFIX: [&str; 4] = ["ru", "su", "xn--p1ai", "yandex.net"];

pub fn build_config(server: &Server, st: &Settings) -> Value {
    let mut proxy = server.outbound.clone();
    proxy["tag"] = json!("proxy");

    let mut direct: Vec<String> = st.direct_domains.clone();
    if st.bypass_ru { direct.extend(RU_SUFFIX.iter().map(|s| s.to_string())); }

    let mut tun = json!({
        "type": "tun", "tag": "tun-in", "inet4_address": "172.19.0.1/30",
        "mtu": st.mtu, "auto_route": true, "strict_route": true, "stack": "mixed", "sniff": true
    });
    match st.split_mode.as_str() {
        "include" if !st.packages.is_empty() => tun["include_package"] = json!(st.packages),
        "exclude" if !st.packages.is_empty() => tun["exclude_package"] = json!(st.packages),
        _ => {}
    }

    let mut rules = vec![json!({"protocol": "dns", "outbound": "dns-out"}), json!({"ip_is_private": true, "outbound": "direct"})];
    if !st.proxy_domains.is_empty() { rules.push(json!({"domain_suffix": st.proxy_domains, "outbound": "proxy"})); }
    if !direct.is_empty() { rules.push(json!({"domain_suffix": direct, "outbound": "direct"})); }

    let mut dns_rules = vec![];
    if !direct.is_empty() { dns_rules.push(json!({"domain_suffix": direct, "server": "local"})); }

    json!({
        "log": {"level": "warn"},
        "dns": {
            "servers": [
                {"tag": "remote", "address": st.remote_dns, "address_resolver": "local", "detour": "proxy"},
                {"tag": "local", "address": "local"}
            ],
            "rules": dns_rules, "final": "remote"
        },
        "inbounds": [tun],
        "outbounds": [proxy, {"type": "direct", "tag": "direct"}, {"type": "block", "tag": "block"}, {"type": "dns", "tag": "dns-out"}],
        "route": {"rules": rules, "auto_detect_interface": true, "final": "proxy"}
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse_link;

    #[test]
    fn split_and_ru() {
        let s = parse_link("trojan://pw@h.com:443#t").unwrap();
        let st = Settings { split_mode: "exclude".into(), packages: vec!["ru.bank.app".into()], ..Default::default() };
        let c = build_config(&s, &st);
        assert_eq!(c["inbounds"][0]["exclude_package"][0], "ru.bank.app");
        assert_eq!(c["outbounds"][0]["tag"], "proxy");
        assert!(c["route"]["rules"].to_string().contains("xn--p1ai"));
    }
}
