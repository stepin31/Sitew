use crate::parse::Server;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(default)]
pub struct Settings {
    /// Российские домены (.ru, .рф, .su) и локальные адреса идут напрямую
    pub bypass_ru: bool,
    /// "off" | "include" (через VPN только перечисленные) | "exclude" (перечисленные мимо VPN)
    pub split_mode: String,
    pub packages: Vec<String>,
    pub direct_domains: Vec<String>,
    pub proxy_domains: Vec<String>,
    pub remote_dns: String,
    pub mtu: u32,
    /// Анализ пакетов (sniffing) — нужен для доменных правил при трафике по IP
    pub sniff: bool,
    pub strict_route: bool,
    /// "auto" | "v4" | "v6" — предпочтительный тип IP при резолвинге
    pub ip_pref: String,
    /// Multiplex (smux) поверх vless/vmess/trojan/ss; для XTLS-flow не применяется
    pub mux: bool,
    /// Сети (CIDR или IP), которые идут мимо VPN
    pub excluded_routes: Vec<String>,
    /// Локальный SOCKS5/HTTP-прокси (mixed inbound)
    pub local_proxy: bool,
    pub local_port: u16,
    pub allow_lan: bool,
    /// "vpn" — TUN на весь трафик; "proxy" — только локальный прокси, без VPN
    pub mode: String,
    /// Резолвить через системный DNS вместо удалённого
    pub use_local_dns: bool,
    /// "error" | "warn" | "info" | "debug"
    pub log_level: String,
    /// Clash API для статистики: порт 0 — выключено
    pub clash_port: u16,
    pub clash_secret: String,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            bypass_ru: true, split_mode: "off".into(), packages: vec![], direct_domains: vec![],
            proxy_domains: vec![], remote_dns: "https://1.1.1.1/dns-query".into(), mtu: 9000,
            sniff: true, strict_route: true, ip_pref: "auto".into(), mux: false, excluded_routes: vec![],
            local_proxy: false, local_port: 10808, allow_lan: false, mode: "vpn".into(), use_local_dns: false,
            log_level: "warn".into(), clash_port: 0, clash_secret: String::new(),
        }
    }
}

const RU_SUFFIX: [&str; 4] = ["ru", "su", "xn--p1ai", "yandex.net"];

/// Приводит IP или CIDR к виду "адрес/префикс"; некорректные записи отбрасывает.
fn normalize_cidr(s: &str) -> Option<String> {
    let s = s.trim();
    let (ip, prefix) = match s.split_once('/') {
        Some((ip, p)) => (ip, Some(p.parse::<u8>().ok()?)),
        None => (s, None),
    };
    let addr: std::net::IpAddr = ip.parse().ok()?;
    let max = if addr.is_ipv4() { 32 } else { 128 };
    let p = prefix.unwrap_or(max);
    if p > max { return None; }
    Some(format!("{addr}/{p}"))
}

pub fn build_config(server: &Server, st: &Settings) -> Value {
    let mut proxy = server.outbound.clone();
    proxy["tag"] = json!("proxy");
    let kind = proxy["type"].as_str().unwrap_or("").to_string();
    if st.mux && proxy.get("flow").is_none() && ["vless", "vmess", "trojan", "shadowsocks"].contains(&kind.as_str()) {
        proxy["multiplex"] = json!({"enabled": true, "protocol": "smux"});
    }

    let mut direct: Vec<String> = st.direct_domains.clone();
    if st.bypass_ru { direct.extend(RU_SUFFIX.iter().map(|s| s.to_string())); }

    let proxy_mode = st.mode == "proxy";
    let mut inbounds: Vec<Value> = vec![];

    if !proxy_mode {
        let mut tun = json!({
            "type": "tun", "tag": "tun-in", "inet4_address": "172.19.0.1/30",
            "mtu": st.mtu, "auto_route": true, "strict_route": st.strict_route, "stack": "mixed", "sniff": st.sniff
        });
        match st.split_mode.as_str() {
            "include" if !st.packages.is_empty() => tun["include_package"] = json!(st.packages),
            "exclude" if !st.packages.is_empty() => tun["exclude_package"] = json!(st.packages),
            _ => {}
        }
        let excl: Vec<String> = st.excluded_routes.iter().filter_map(|r| normalize_cidr(r)).collect();
        if !excl.is_empty() { tun["route_exclude_address"] = json!(excl); }
        inbounds.push(tun);
    }
    if proxy_mode || st.local_proxy {
        inbounds.push(json!({
            "type": "mixed", "tag": "mixed-in",
            "listen": if st.allow_lan { "0.0.0.0" } else { "127.0.0.1" },
            "listen_port": st.local_port, "sniff": st.sniff
        }));
    }

    let mut rules = vec![json!({"protocol": "dns", "outbound": "dns-out"}), json!({"ip_is_private": true, "outbound": "direct"})];
    if !st.proxy_domains.is_empty() { rules.push(json!({"domain_suffix": st.proxy_domains, "outbound": "proxy"})); }
    if !direct.is_empty() { rules.push(json!({"domain_suffix": direct, "outbound": "direct"})); }

    let mut dns_rules = vec![];
    if !direct.is_empty() { dns_rules.push(json!({"domain_suffix": direct, "server": "local"})); }

    let remote = if st.use_local_dns {
        json!({"tag": "remote", "address": "local"})
    } else {
        json!({"tag": "remote", "address": st.remote_dns, "address_resolver": "local", "detour": "proxy"})
    };
    let mut dns = json!({
        "servers": [remote, {"tag": "local", "address": "local"}],
        "rules": dns_rules, "final": "remote"
    });
    match st.ip_pref.as_str() {
        "v4" => dns["strategy"] = json!("prefer_ipv4"),
        "v6" => dns["strategy"] = json!("prefer_ipv6"),
        _ => {}
    }

    let level = if ["debug", "info", "warn", "error"].contains(&st.log_level.as_str()) { st.log_level.as_str() } else { "warn" };

    let mut cfg = json!({
        "log": {"level": level},
        "dns": dns,
        "inbounds": inbounds,
        "outbounds": [proxy, {"type": "direct", "tag": "direct"}, {"type": "block", "tag": "block"}, {"type": "dns", "tag": "dns-out"}],
        "route": {"rules": rules, "auto_detect_interface": true, "final": "proxy"}
    });
    if st.clash_port > 0 {
        cfg["experimental"] = json!({"clash_api": {
            "external_controller": format!("127.0.0.1:{}", st.clash_port),
            "secret": st.clash_secret
        }});
    }
    cfg
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse_link;

    #[test]
    fn split_and_ru() {
        let s = parse_link("trojan://pw@h.com:443#t").unwrap();
        let st = Settings { split_mode: "exclude".into(), packages: vec!["ru.bank.app".into()], ..Default::default() };
        let c = build_config(&s, &st);
        assert_eq!(c["inbounds"][0]["exclude_package"][0], "ru.bank.app");
        assert_eq!(c["outbounds"][0]["tag"], "proxy");
        assert!(c["route"]["rules"].to_string().contains("xn--p1ai"));
    }

    #[test]
    fn new_options() {
        let s = parse_link("vless://u@1.1.1.1:443?security=tls#a").unwrap();
        let st = Settings {
            mux: true, ip_pref: "v6".into(), sniff: false, local_proxy: true, allow_lan: true,
            excluded_routes: vec!["192.168.0.0/16".into(), "10.1.2.3".into(), "мусор".into()],
            log_level: "debug".into(), clash_port: 9090, clash_secret: "s".into(), ..Default::default()
        };
        let c = build_config(&s, &st);
        assert_eq!(c["outbounds"][0]["multiplex"]["enabled"], true);
        assert_eq!(c["dns"]["strategy"], "prefer_ipv6");
        assert_eq!(c["inbounds"][0]["sniff"], false);
        assert_eq!(c["inbounds"][0]["route_exclude_address"].as_array().unwrap().len(), 2);
        assert_eq!(c["inbounds"][1]["listen"], "0.0.0.0");
        assert_eq!(c["log"]["level"], "debug");
        assert_eq!(c["experimental"]["clash_api"]["external_controller"], "127.0.0.1:9090");
        // режим прокси: без TUN
        let p = build_config(&s, &Settings { mode: "proxy".into(), ..Default::default() });
        assert_eq!(p["inbounds"].as_array().unwrap().len(), 1);
        assert_eq!(p["inbounds"][0]["type"], "mixed");
        // XTLS-flow несовместим с mux
        let f = parse_link("vless://u@1.1.1.1:443?security=reality&pbk=k&flow=xtls-rprx-vision#f").unwrap();
        assert!(build_config(&f, &Settings { mux: true, ..Default::default() })["outbounds"][0].get("multiplex").is_none());
    }
}
