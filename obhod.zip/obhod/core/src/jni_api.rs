//! JNI-мост для Kotlin-класса app.obhod.client.Core. Все данные передаются JSON-строками.
use crate::{config, parse, ping};
use jni::objects::{JObject, JString};
use jni::sys::{jlong, jstring};
use jni::JNIEnv;

fn out(env: &mut JNIEnv, s: String) -> jstring {
    env.new_string(s).map(|j| j.into_raw()).unwrap_or(std::ptr::null_mut())
}
fn inp(env: &mut JNIEnv, s: &JString) -> String {
    env.get_string(s).map(|j| j.into()).unwrap_or_default()
}

#[no_mangle]
pub extern "system" fn Java_app_obhod_client_Core_parseSubscription(mut env: JNIEnv, _o: JObject, text: JString) -> jstring {
    let t = inp(&mut env, &text);
    out(&mut env, serde_json::to_string(&parse::parse_subscription(&t)).unwrap_or("[]".into()))
}

#[no_mangle]
pub extern "system" fn Java_app_obhod_client_Core_parseLink(mut env: JNIEnv, _o: JObject, link: JString) -> jstring {
    let l = inp(&mut env, &link);
    let r = parse::parse_link(&l).map(|s| serde_json::to_string(&s).unwrap_or_default()).unwrap_or_default();
    out(&mut env, r)
}

#[no_mangle]
pub extern "system" fn Java_app_obhod_client_Core_buildConfig(mut env: JNIEnv, _o: JObject, server: JString, settings: JString) -> jstring {
    let (s, st) = (inp(&mut env, &server), inp(&mut env, &settings));
    let r = match serde_json::from_str::<parse::Server>(&s) {
        Ok(srv) => config::build_config(&srv, &serde_json::from_str(&st).unwrap_or_default()).to_string(),
        Err(_) => String::new(),
    };
    out(&mut env, r)
}

#[no_mangle]
pub extern "system" fn Java_app_obhod_client_Core_pingAll(mut env: JNIEnv, _o: JObject, servers: JString, timeout_ms: jlong) -> jstring {
    let s = inp(&mut env, &servers);
    let list: Vec<parse::Server> = serde_json::from_str(&s).unwrap_or_default();
    out(&mut env, serde_json::to_string(&ping::ping_all(&list, timeout_ms as u64)).unwrap_or("[]".into()))
}
