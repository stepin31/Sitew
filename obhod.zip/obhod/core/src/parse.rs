use base64::{engine::general_purpose::{STANDARD_NO_PAD, URL_SAFE_NO_PAD}, Engine};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Server {
    pub name: String,
    pub protocol: String,
    pub host: String,
    pub port: u16,
    /// Готовый outbound для sing-box (tag выставляется при сборке конфига)
    pub outbound: Value,
}

type Q = HashMap<String, String>;

fn b64(s: &str) -> Option<String> {
    let c: String = s.chars().filter(|c| !c.is_whitespace() && *c != '=').collect();
    let bytes = STANDARD_NO_PAD.decode(&c).or_else(|_| URL_SAFE_NO_PAD.decode(&c)).ok()?;
    String::from_utf8(bytes).ok()
}

fn pct(s: &str) -> String {
    let b = s.as_bytes();
    let (mut o, mut i) = (Vec::new(), 0);
    while i < b.len() {
        if b[i] == b'%' && i + 2 < b.len() + 0 + 1 && i + 2 <= b.len() - 1 {
            if let Some(v) = std::str::from_utf8(&b[i + 1..i + 3]).ok().and_then(|h| u8::from_str_radix(h, 16).ok()) {
                o.push(v);
                i += 3;
                continue;
            }
        }
        o.push(b[i]);
        i += 1;
    }
    String::from_utf8_lossy(&o).into_owned()
}

struct Parts { user: String, host: String, port: u16, q: Q, name: String }

fn split_host_port(hp: &str) -> Result<(String, u16), String> {
    let (h, p) = hp.rsplit_once(':').ok_or("нет порта")?;
    let port = p.trim_end_matches('/').parse().map_err(|_| "плохой порт")?;
    Ok((h.trim_matches(|c| c == '[' || c == ']').to_string(), port))
}

fn split_url(rest: &str) -> Result<Parts, String> {
    let (rest, frag) = rest.split_once('#').unwrap_or((rest, ""));
    let (auth, query) = rest.split_once('?').unwrap_or((rest, ""));
    let (user, hp) = auth.rsplit_once('@').unwrap_or(("", auth));
    let (host, port) = split_host_port(hp.trim_end_matches('/'))?;
    let q = query
        .split('&')
        .filter_map(|kv| kv.split_once('='))
        .map(|(k, v)| (k.to_string(), pct(v)))
        .collect();
    Ok(Parts { user: pct(user), host, port, q, name: pct(frag) })
}

fn flag(q: &Q, keys: &[&str]) -> bool {
    keys.iter().any(|k| matches!(q.get(*k).map(|s| s.as_str()), Some("1") | Some("true")))
}

fn tls(q: &Q, host: &str, force: bool) -> Option<Value> {
    let sec = q.get("security").map(|s| s.as_str()).unwrap_or(if force { "tls" } else { "" });
    if sec != "tls" && sec != "reality" {
        return None;
    }
    let sni = q.get("sni").or(q.get("peer")).cloned().unwrap_or_else(|| host.to_string());
    let mut t = json!({"enabled": true, "server_name": sni});
    if flag(q, &["allowInsecure", "insecure"]) { t["insecure"] = json!(true); }
    if let Some(a) = q.get("alpn").filter(|a| !a.is_empty()) {
        t["alpn"] = json!(a.split(',').collect::<Vec<_>>());
    }
    if let Some(fp) = q.get("fp").filter(|f| !f.is_empty()) {
        t["utls"] = json!({"enabled": true, "fingerprint": fp});
    }
    if sec == "reality" {
        t["reality"] = json!({"enabled": true,
            "public_key": q.get("pbk").cloned().unwrap_or_default(),
            "short_id": q.get("sid").cloned().unwrap_or_default()});
        if t.get("utls").is_none() {
            t["utls"] = json!({"enabled": true, "fingerprint": "chrome"});
        }
    }
    Some(t)
}

fn transport(q: &Q) -> Option<Value> {
    let path = q.get("path").cloned().unwrap_or_else(|| "/".into());
    match q.get("type").map(|s| s.as_str()).unwrap_or("tcp") {
        "ws" => {
            let mut t = json!({"type": "ws", "path": path});
            if let Some(h) = q.get("host").filter(|h| !h.is_empty()) { t["headers"] = json!({"Host": h}); }
            Some(t)
        }
        "grpc" => Some(json!({"type": "grpc", "service_name": q.get("serviceName").cloned().unwrap_or_default()})),
        "httpupgrade" => Some(json!({"type": "httpupgrade", "path": path, "host": q.get("host").cloned().unwrap_or_default()})),
        "http" | "h2" => Some(json!({"type": "http", "path": path, "host": q.get("host").map(|h| vec![h.clone()]).unwrap_or_default()})),
        _ => None,
    }
}

fn finish(mut p: Parts, protocol: &str, mut ob: Value, tls_v: Option<Value>, tr: Option<Value>) -> Server {
    ob["server"] = json!(p.host);
    ob["server_port"] = json!(p.port);
    if let Some(t) = tls_v { ob["tls"] = t; }
    if let Some(t) = tr { ob["transport"] = t; }
    if p.name.is_empty() { p.name = format!("{}:{}", p.host, p.port); }
    Server { name: p.name, protocol: protocol.into(), host: p.host, port: p.port, outbound: ob }
}

fn parse_vless(rest: &str) -> Result<Server, String> {
    let p = split_url(rest)?;
    let mut ob = json!({"type": "vless", "uuid": p.user, "packet_encoding": "xudp"});
    if let Some(f) = p.q.get("flow").filter(|f| !f.is_empty()) { ob["flow"] = json!(f); }
    let (t, tr) = (tls(&p.q, &p.host, false), transport(&p.q));
    Ok(finish(p, "vless", ob, t, tr))
}

fn parse_trojan(rest: &str) -> Result<Server, String> {
    let p = split_url(rest)?;
    let ob = json!({"type": "trojan", "password": p.user});
    let (t, tr) = (tls(&p.q, &p.host, true), transport(&p.q));
    Ok(finish(p, "trojan", ob, t, tr))
}

fn parse_hy2(rest: &str) -> Result<Server, String> {
    let p = split_url(rest)?;
    let mut ob = json!({"type": "hysteria2", "password": p.user});
    if let Some(o) = p.q.get("obfs").filter(|o| !o.is_empty()) {
        ob["obfs"] = json!({"type": o, "password": p.q.get("obfs-password").cloned().unwrap_or_default()});
    }
    let mut t = json!({"enabled": true, "server_name": p.q.get("sni").cloned().unwrap_or_else(|| p.host.clone()), "alpn": ["h3"]});
    if flag(&p.q, &["insecure"]) { t["insecure"] = json!(true); }
    Ok(finish(p, "hysteria2", ob, Some(t), None))
}

fn parse_ss(rest: &str) -> Result<Server, String> {
    let (main, frag) = rest.split_once('#').unwrap_or((rest, ""));
    let main = main.split('?').next().unwrap_or("");
    let (cred, hp) = if let Some((u, h)) = main.rsplit_once('@') {
        (b64(u).unwrap_or_else(|| pct(u)), h.to_string())
    } else {
        let d = b64(main).ok_or("ss: не base64")?;
        let (c, h) = d.rsplit_once('@').ok_or("ss: формат")?;
        (c.to_string(), h.to_string())
    };
    let (method, pass) = cred.split_once(':').ok_or("ss: нет метода")?;
    let (host, port) = split_host_port(hp.trim_end_matches('/'))?;
    let p = Parts { user: String::new(), host, port, q: HashMap::new(), name: pct(frag) };
    let ob = json!({"type": "shadowsocks", "method": method, "password": pass});
    Ok(finish(p, "shadowsocks", ob, None, None))
}

fn parse_vmess(rest: &str) -> Result<Server, String> {
    let v: Value = serde_json::from_str(&b64(rest).ok_or("vmess: не base64")?).map_err(|e| e.to_string())?;
    let s = |k: &str| match &v[k] { Value::String(s) => s.clone(), Value::Number(n) => n.to_string(), _ => String::new() };
    let net = s("net");
    let mut q: Q = HashMap::new();
    q.insert("type".into(), if net.is_empty() { "tcp".into() } else { net.clone() });
    q.insert("path".into(), s("path"));
    if net == "grpc" { q.insert("serviceName".into(), s("path")); }
    for (src, dst) in [("host", "host"), ("sni", "sni"), ("fp", "fp"), ("alpn", "alpn")] { q.insert(dst.into(), s(src)); }
    if s("tls") == "tls" { q.insert("security".into(), "tls".into()); }
    let port: u16 = s("port").parse().map_err(|_| "vmess: порт")?;
    let p = Parts { user: String::new(), host: s("add"), port, name: s("ps"), q };
    let ob = json!({"type": "vmess", "uuid": s("id"),
        "security": if s("scy").is_empty() { "auto".into() } else { s("scy") },
        "alter_id": s("aid").parse::<u32>().unwrap_or(0)});
    let (t, tr) = (tls(&p.q, &p.host, false), transport(&p.q));
    Ok(finish(p, "vmess", ob, t, tr))
}

pub fn parse_link(link: &str) -> Result<Server, String> {
    let (scheme, rest) = link.trim().split_once("://").ok_or("нет схемы")?;
    match scheme.to_ascii_lowercase().as_str() {
        "vless" => parse_vless(rest),
        "vmess" => parse_vmess(rest),
        "trojan" => parse_trojan(rest),
        "ss" => parse_ss(rest),
        "hysteria2" | "hy2" => parse_hy2(rest),
        s => Err(format!("неподдерживаемая схема: {s}")),
    }
}

/// Тело подписки: список ссылок построчно, обычный или в base64.
pub fn parse_subscription(text: &str) -> Vec<Server> {
    let t = text.trim();
    let body = if t.contains("://") { t.to_string() } else { b64(t).unwrap_or_else(|| t.to_string()) };
    body.lines().filter_map(|l| parse_link(l).ok()).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vless_reality() {
        let s = parse_link("vless://11111111-2222-3333-4444-555555555555@1.2.3.4:443?type=tcp&security=reality&pbk=PUB&sid=ab&sni=www.example.com&fp=chrome&flow=xtls-rprx-vision#My%20Node").unwrap();
        assert_eq!(s.name, "My Node");
        assert_eq!(s.outbound["tls"]["reality"]["public_key"], "PUB");
        assert_eq!(s.outbound["flow"], "xtls-rprx-vision");
    }

    #[test]
    fn vmess_ws() {
        let j = r#"{"v":"2","ps":"vm","add":"h.com","port":"443","id":"u","aid":"0","net":"ws","host":"h.com","path":"/p","tls":"tls"}"#;
        let l = format!("vmess://{}", base64::engine::general_purpose::STANDARD.encode(j));
        let s = parse_link(&l).unwrap();
        assert_eq!(s.outbound["transport"]["type"], "ws");
        assert_eq!(s.outbound["tls"]["enabled"], true);
    }

    #[test]
    fn ss_both_forms() {
        let a = parse_link("ss://YWVzLTEyOC1nY206cGFzcw@h.com:8388#a").unwrap();
        let b = parse_link("ss://YWVzLTEyOC1nY206cGFzc0BoLmNvbTo4Mzg4#b").unwrap();
        assert_eq!(a.outbound["method"], "aes-128-gcm");
        assert_eq!((b.host.as_str(), b.port), ("h.com", 8388));
    }

    #[test]
    fn trojan_hy2_and_subscription() {
        assert_eq!(parse_link("trojan://pw@h.com:443?sni=x.com#t").unwrap().outbound["tls"]["server_name"], "x.com");
        let h = parse_link("hy2://pw@h.com:8443?insecure=1&obfs=salamander&obfs-password=o#h").unwrap();
        assert_eq!(h.outbound["obfs"]["password"], "o");
        let raw = "trojan://pw@h.com:443#a\nvless://u@1.1.1.1:443#b\nmusor";
        let enc = base64::engine::general_purpose::STANDARD.encode(raw);
        assert_eq!(parse_subscription(&enc).len(), 2);
        assert_eq!(parse_subscription(raw).len(), 2);
    }
}
