use crate::parse::Server;
use std::net::{TcpStream, ToSocketAddrs};
use std::time::{Duration, Instant};

/// Время TCP-подключения в мс, либо -1.
pub fn tcp_ping(host: &str, port: u16, timeout_ms: u64) -> i64 {
    let Some(addr) = (host, port).to_socket_addrs().ok().and_then(|mut a| a.next()) else { return -1 };
    let t = Instant::now();
    match TcpStream::connect_timeout(&addr, Duration::from_millis(timeout_ms)) {
        Ok(_) => t.elapsed().as_millis() as i64,
        Err(_) => -1,
    }
}

pub fn ping_all(servers: &[Server], timeout_ms: u64) -> Vec<i64> {
    let hs: Vec<_> = servers.iter().map(|s| {
        let (h, p) = (s.host.clone(), s.port);
        std::thread::spawn(move || tcp_ping(&h, p, timeout_ms))
    }).collect();
    hs.into_iter().map(|h| h.join().unwrap_or(-1)).collect()
}
