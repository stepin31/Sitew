//! Ядро клиента: разбор ссылок/подписок, генерация конфига sing-box, пинг.
pub mod config;
pub mod jni_api;
pub mod parse;
pub mod ping;
