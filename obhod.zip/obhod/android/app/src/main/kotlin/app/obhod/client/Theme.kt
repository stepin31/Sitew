package app.obhod.client

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Ok = Color(0xFF22C55E)
val Warn = Color(0xFFF59E0B)
val Bad = Color(0xFFEF4444)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8B93FF), onPrimary = Color(0xFF10123A),
    primaryContainer = Color(0xFF2A2F66), onPrimaryContainer = Color(0xFFE0E1FF),
    background = Color(0xFF0B0D12), onBackground = Color(0xFFE8EAF2),
    surface = Color(0xFF12151C), onSurface = Color(0xFFE8EAF2),
    surfaceVariant = Color(0xFF1B2029), onSurfaceVariant = Color(0xFF9AA3B5),
    outline = Color(0xFF2B3342), outlineVariant = Color(0xFF2A3140),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF4F46E5), onPrimary = Color.White,
    primaryContainer = Color(0xFFE3E4FF), onPrimaryContainer = Color(0xFF1B1A55),
    background = Color(0xFFF4F5FA), onBackground = Color(0xFF14161C),
    surface = Color.White, onSurface = Color(0xFF14161C),
    surfaceVariant = Color.White, onSurfaceVariant = Color(0xFF626B7F),
    outline = Color(0xFFD9DCE8), outlineVariant = Color(0xFFE6E8F1),
)

@Composable
fun isDark(mode: String): Boolean = when (mode) {
    "dark" -> true
    "light" -> false
    else -> isSystemInDarkTheme()
}

@Composable
fun ObhodTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp),
        ),
        content = content,
    )
}
