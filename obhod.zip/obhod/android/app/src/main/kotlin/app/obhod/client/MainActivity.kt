package app.obhod.client

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf<String?>(null)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        incoming = intent?.dataString
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Screen(Store(this), incoming) } }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); incoming = i.dataString }
}

@Composable
fun Screen(store: Store, deeplink: String?) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var servers by remember { mutableStateOf(store.servers) }
    var pings by remember { mutableStateOf(emptyList<Long>()) }
    var selected by remember { mutableIntStateOf(store.selected) }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var on by remember { mutableStateOf(ObhodVpnService.running) }

    fun add(text: String) = scope.launch {
        msg = runCatching { withContext(Dispatchers.IO) { store.addInput(text) } }
            .fold({ "Добавлено серверов: $it" }, { "Ошибка: ${it.message}" })
        servers = store.servers
    }
    fun start() {
        store.selected = selected
        ctx.startForegroundService(Intent(ctx, ObhodVpnService::class.java)); on = true
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { if (it.resultCode == -1) start() }

    LaunchedEffect(deeplink) {
        deeplink?.let { d -> add(if (d.startsWith("obhod://")) android.net.Uri.parse(d).getQueryParameter("url") ?: d else d) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).statusBarsPadding()) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), label = { Text("Подписка или ссылка") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            Button({ add(input); input = "" }) { Text("+") }
        }
        Text(msg, Modifier.padding(vertical = 4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ scope.launch {
                withContext(Dispatchers.IO) { store.refreshAll() }; servers = store.servers
            } }) { Text("Обновить") }
            OutlinedButton({ scope.launch { pings = withContext(Dispatchers.IO) { Core.pings(servers) } } }) { Text("Пинг") }
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(servers) { i, sv ->
                ListItem(
                    headlineContent = { Text(sv.getString("name")) },
                    supportingContent = { Text("${sv.getString("protocol")} · ${sv.getString("host")}:${sv.getInt("port")}") },
                    trailingContent = { pings.getOrNull(i)?.let { Text(if (it < 0) "—" else "$it мс") } },
                    colors = if (i == selected) ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.primaryContainer) else ListItemDefaults.colors(),
                    modifier = Modifier.clickable { selected = i }
                )
            }
        }
        Button({
            if (on) { ctx.startService(Intent(ctx, ObhodVpnService::class.java).setAction(ObhodVpnService.ACTION_STOP)); on = false }
            else VpnService.prepare(ctx)?.let { perm.launch(it) } ?: start()
        }, Modifier.fillMaxWidth().height(56.dp), enabled = servers.isNotEmpty()) { Text(if (on) "Отключить" else "Подключить") }
    }
}
