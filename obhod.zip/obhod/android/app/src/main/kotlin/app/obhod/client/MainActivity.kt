package app.obhod.client

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf<String?>(null)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        incoming = intent?.dataString
        val store = Store(this)
        setContent {
            var theme by remember { mutableStateOf(store.theme) }
            val dark = isDark(theme)
            DisposableEffect(dark) {
                val style = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            ObhodTheme(dark) { App(store, incoming, theme) { theme = it; store.theme = it } }
        }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); incoming = i.dataString }
}

@Composable
fun App(store: Store, deeplink: String?, theme: String, onTheme: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val st = remember { AppState(store) }
    val snack = remember { SnackbarHostState() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    fun say(text: String) { scope.launch { snack.showSnackbar(text) } }

    fun pingList(list: List<org.json.JSONObject>, replace: Boolean) {
        if (list.isEmpty()) return
        scope.launch {
            val cfg = store.settings
            val r = pingServers(list, cfg.optString("ping_type", "tcp"), cfg.optInt("ping_timeout", 5) * 1000L)
            if (r.size == list.size) {
                val m = list.indices.associate { Store.key(list[it]) to r[it] }
                st.pings = if (replace) m else st.pings + m
            }
        }
    }

    fun pingAll() = pingList(st.servers, true)

    fun add(text: String) {
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { store.addInput(text) } }
            st.reload()
            r.onSuccess { say(if (it == 0) "Серверы не найдены" else "Добавлено серверов: $it") }
                .onFailure { say("Ошибка: ${it.message}") }
            pingAll()
        }
    }

    fun refresh() {
        if (st.refreshing) return
        scope.launch {
            st.refreshing = true
            val ok = withContext(Dispatchers.IO) { runCatching { store.refreshAll() }.getOrDefault(0) }
            st.reload()
            st.refreshing = false
            say(if (store.subscriptionCount == 0) "Нет подписок" else if (ok == 0) "Не удалось обновить" else "Подписки обновлены")
            pingAll()
        }
    }

    fun refreshSub(url: String) {
        if (st.refreshingUrl != null) return
        scope.launch {
            st.refreshingUrl = url
            val ok = withContext(Dispatchers.IO) { runCatching { store.refreshSub(url) }.isSuccess }
            st.reload()
            st.refreshingUrl = null
            say(if (ok) "Подписка обновлена" else "Не удалось обновить подписку")
            st.groups.firstOrNull { it.key == url }?.let { pingList(it.servers, false) }
        }
    }

    fun deleteGroup(g: SubGroup) {
        scope.launch {
            withContext(Dispatchers.IO) { if (g.url != null) store.removeSubscription(g.url) else store.clearManual() }
            st.reload()
        }
    }

    fun startVpn() {
        st.selectedServer?.let { store.selectedKey = Store.key(it) }
        ObhodVpnService.lastError = null
        st.error = null
        st.connecting = true
        st.connectStart = System.currentTimeMillis()
        ctx.startForegroundService(Intent(ctx, ObhodVpnService::class.java))
    }

    fun stopVpn() {
        ctx.startService(Intent(ctx, ObhodVpnService::class.java).setAction(ObhodVpnService.ACTION_STOP))
        st.connecting = false
        st.running = false
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn()
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun toggle() {
        when {
            st.running || st.connecting -> stopVpn()
            st.servers.isEmpty() -> showAdd = true
            else -> VpnService.prepare(ctx)?.let { perm.launch(it) } ?: startVpn()
        }
    }

    fun select(sv: org.json.JSONObject) {
        val wasOn = st.running || st.connecting
        st.selectedKey = Store.key(sv)
        store.selectedKey = st.selectedKey
        if (wasOn) scope.launch { stopVpn(); delay(900); startVpn() }
    }

    // состояние сервиса
    LaunchedEffect(Unit) {
        while (true) {
            st.running = ObhodVpnService.running
            if (st.running) st.connecting = false
            val e = ObhodVpnService.lastError
            if (st.connecting && e != null) { st.connecting = false; st.error = e }
            if (st.connecting && System.currentTimeMillis() - st.connectStart > 25000) {
                st.connecting = false; st.error = "Не удалось подключиться: таймаут"
            }
            delay(400)
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (store.autoUpdate && store.subscriptionCount > 0) {
            st.refreshing = true
            withContext(Dispatchers.IO) { runCatching { store.refreshAll(onlyDue = true) } }
            st.refreshing = false
            st.reload()
        }
        pingAll()
    }

    LaunchedEffect(deeplink) {
        deeplink?.let { d ->
            add(if (d.startsWith("obhod://")) android.net.Uri.parse(d).getQueryParameter("url") ?: d else d)
        }
    }

    Scaffold(
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = cs.surface) {
                val colors = NavigationBarItemDefaults.colors(
                    indicatorColor = cs.primaryContainer, selectedIconColor = cs.onPrimaryContainer,
                    selectedTextColor = cs.onSurface, unselectedIconColor = cs.onSurfaceVariant,
                    unselectedTextColor = cs.onSurfaceVariant,
                )
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Rounded.Home, null) }, label = { Text("Главная") }, colors = colors)
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Rounded.Settings, null) }, label = { Text("Настройки") }, colors = colors)
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            if (tab == 0) {
                HomeScreen(
                    st, onToggle = { toggle() }, onSelect = { select(it) }, onAdd = { showAdd = true },
                    onPingAll = { pingAll() }, onRefreshSub = { refreshSub(it) },
                    onPingGroup = { pingList(it.servers, false) }, onDeleteGroup = { deleteGroup(it) },
                )
            } else {
                SettingsScreen(
                    st, theme, onTheme, onRefresh = { refresh() },
                    onClear = { store.clearServers(); st.reload(); st.pings = emptyMap() },
                )
            }
        }
    }

    if (showAdd) AddDialog(onDismiss = { showAdd = false }, onAdd = { showAdd = false; add(it) })
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить") },
        text = {
            Column {
                OutlinedTextField(
                    text, { text = it }, label = { Text("Ссылка подписки или vless://…") },
                    minLines = 3, modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { clip.getText()?.text?.let { text = it } }) { Text("Вставить из буфера") }
            }
        },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onAdd(text) }) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
