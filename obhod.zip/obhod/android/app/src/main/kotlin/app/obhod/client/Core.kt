package app.obhod.client

import org.json.JSONArray
import org.json.JSONObject

/** Мост к Rust-ядру (libobhod_core.so). Обмен — JSON-строки. */
object Core {
    init { System.loadLibrary("obhod_core") }
    external fun parseSubscription(text: String): String
    external fun parseLink(link: String): String
    external fun buildConfig(serverJson: String, settingsJson: String): String
    external fun pingAll(serversJson: String, timeoutMs: Long): String

    fun servers(text: String): List<JSONObject> =
        JSONArray(parseSubscription(text)).let { a -> List(a.length()) { a.getJSONObject(it) } }

    /** TCP-пинг всех серверов параллельно: мс или -1. */
    fun pings(servers: List<JSONObject>, timeoutMs: Long = 3000): List<Long> =
        JSONArray(pingAll(JSONArray(servers).toString(), timeoutMs)).let { a -> List(a.length()) { a.getLong(it) } }
}
