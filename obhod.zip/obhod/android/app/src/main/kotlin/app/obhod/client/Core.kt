package app.obhod.client

import org.json.JSONArray
import org.json.JSONObject

/** Мост к Rust-ядру (libobhod_core.so). Всё обмен — JSON-строки. */
object Core {
    init { System.loadLibrary("obhod_core") }
    external fun parseSubscription(text: String): String
    external fun parseLink(link: String): String
    external fun buildConfig(serverJson: String, settingsJson: String): String
    external fun pingAll(serversJson: String, timeoutMs: Long): String

    fun servers(text: String): List<JSONObject> =
        JSONArray(parseSubscription(text)).let { a -> List(a.length()) { a.getJSONObject(it) } }

    fun pings(servers: List<JSONObject>): List<Long> =
        JSONArray(pingAll(JSONArray(servers).toString(), 3000)).let { a -> List(a.length()) { a.getLong(it) } }
}
