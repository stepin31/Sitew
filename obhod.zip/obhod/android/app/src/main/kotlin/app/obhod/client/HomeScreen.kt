package app.obhod.client

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

/** Общее состояние экрана. */
class AppState(val store: Store) {
    var groups by mutableStateOf(store.groups())
    var collapsed by mutableStateOf(store.collapsed)
    var selectedKey by mutableStateOf(store.selectedKey)
    var pings by mutableStateOf(emptyMap<String, Long>())
    var running by mutableStateOf(ObhodVpnService.running)
    var connecting by mutableStateOf(false)
    var connectStart by mutableLongStateOf(0L)
    var error by mutableStateOf<String?>(null)
    var refreshing by mutableStateOf(false)
    var refreshingUrl by mutableStateOf<String?>(null)

    val servers: List<JSONObject> get() = groups.flatMap { it.servers }
    val selectedServer: JSONObject?
        get() = servers.let { l -> l.firstOrNull { Store.key(it) == selectedKey } ?: l.firstOrNull() }

    fun reload() {
        groups = store.groups()
        if (servers.none { Store.key(it) == selectedKey }) selectedKey = servers.firstOrNull()?.let { Store.key(it) }
    }

    fun setCollapsed(key: String, value: Boolean) {
        collapsed = if (value) collapsed + key else collapsed - key
        store.collapsed = collapsed
    }

    fun setAllCollapsed(value: Boolean) {
        collapsed = if (value) groups.map { it.key }.toSet() else emptySet()
        store.collapsed = collapsed
    }
}

@Composable
fun HomeScreen(
    st: AppState,
    onToggle: () -> Unit,
    onSelect: (JSONObject) -> Unit,
    onAdd: () -> Unit,
    onPingAll: () -> Unit,
    onRefreshSub: (String) -> Unit,
    onPingGroup: (SubGroup) -> Unit,
    onDeleteGroup: (SubGroup) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val allCollapsed = st.groups.isNotEmpty() && st.groups.all { it.key in st.collapsed }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Обход", Modifier.weight(1f), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)
                FilledTonalIconButton(onClick = onAdd) { Icon(Icons.Rounded.Add, contentDescription = "Добавить") }
            }
        }
        item { ConnectCard(st, onToggle) }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPingAll) { Text("Проверить пинг") }
                Spacer(Modifier.weight(1f))
                if (st.groups.isNotEmpty()) {
                    TextButton(onClick = { st.setAllCollapsed(!allCollapsed) }) {
                        Text(if (allCollapsed) "Показать все" else "Скрыть все")
                    }
                }
            }
        }
        if (st.groups.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Пока нет серверов", color = cs.onSurfaceVariant, fontSize = 16.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onAdd) { Text("Добавить подписку") }
                }
            }
        }
        items(st.groups, key = { it.key }) { g ->
            SubscriptionCard(
                g, st,
                refreshing = st.refreshing && g.url != null || st.refreshingUrl == g.url && g.url != null,
                onSelect = onSelect,
                onRefresh = { g.url?.let(onRefreshSub) },
                onPing = { onPingGroup(g) },
                onDelete = { onDeleteGroup(g) },
            )
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun SubscriptionCard(
    g: SubGroup,
    st: AppState,
    refreshing: Boolean,
    onSelect: (JSONObject) -> Unit,
    onRefresh: () -> Unit,
    onPing: () -> Unit,
    onDelete: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val collapsed = g.key in st.collapsed
    val meta = g.meta
    var menu by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val angle by animateFloatAsState(if (collapsed) -90f else 0f, label = "chevron")

    val subtitle = if (meta != null) {
        val upd = meta.optLong("updated")
        val h = meta.optInt("interval").let { if (it > 0) it else 24 }
        (if (upd > 0) fmtDate(upd) else "не обновлялась") + " | Автообновление - $h ч. · ${g.servers.size}"
    } else "Серверов: ${g.servers.size}"

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceVariant)) {
        // заголовок: нажатие сворачивает/разворачивает блок
        Row(
            Modifier.fillMaxWidth().clickable { st.setCollapsed(g.key, !collapsed) }
                .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Rounded.KeyboardArrowDown, contentDescription = null, tint = cs.onSurfaceVariant,
                modifier = Modifier.size(28.dp).rotate(angle),
            )
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(g.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = cs.onSurface)
                Text(subtitle, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (g.url != null) {
                IconButton(onClick = onRefresh, modifier = Modifier.size(40.dp)) {
                    if (refreshing) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Rounded.Refresh, contentDescription = "Обновить", tint = cs.onSurfaceVariant)
                }
            }
            IconButton(onClick = onPing, modifier = Modifier.size(40.dp)) { GaugeIcon(cs.onSurfaceVariant) }
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "Меню", tint = cs.onSurfaceVariant)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (g.url != null) {
                        DropdownMenuItem(text = { Text("Информация") }, onClick = { menu = false; info = true })
                        DropdownMenuItem(text = { Text("Копировать ссылку") }, onClick = {
                            menu = false
                            clip.setText(AnnotatedString(g.url))
                            android.widget.Toast.makeText(ctx, "Ссылка скопирована", android.widget.Toast.LENGTH_SHORT).show()
                        })
                    }
                    DropdownMenuItem(
                        text = { Text(if (g.url != null) "Удалить подписку" else "Удалить все", color = Bad) },
                        onClick = { menu = false; confirm = true },
                    )
                }
            }
        }

        // строка с трафиком и сроком — видна и в свёрнутом виде
        if (meta != null && (meta.optBoolean("has_info") || meta.optString("support").isNotBlank())) {
            Row(
                Modifier.fillMaxWidth().background(cs.primary.copy(alpha = 0.08f)).padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { info = true }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.Info, contentDescription = "Информация", tint = cs.primary)
                }
                if (meta.optBoolean("has_info")) {
                    TrafficBar(meta.optLong("used"), meta.optLong("total"), Modifier.weight(1f).padding(horizontal = 8.dp))
                    val exp = meta.optLong("expire")
                    if (exp > 0) {
                        val left = exp * 1000 - System.currentTimeMillis()
                        Text(
                            "Истекает: ${fmtDay(exp)}", fontSize = 12.sp,
                            color = when { left < 0 -> Bad; left < 3 * 86_400_000L -> Warn; else -> cs.onSurface },
                        )
                    }
                } else Spacer(Modifier.weight(1f))
                val support = meta.optString("support")
                if (support.isNotBlank()) {
                    IconButton(onClick = { openUrl(ctx, support) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Send, contentDescription = "Поддержка", tint = cs.primary)
                    }
                }
            }
        }

        if (!collapsed) {
            val announce = meta?.optString("announce").orEmpty()
            if (announce.isNotBlank()) {
                Text(
                    announce, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    fontSize = 13.sp, textAlign = TextAlign.Center, color = cs.onSurface,
                )
            }
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (g.servers.isEmpty()) {
                    Text("Нет серверов — обновите подписку", color = cs.onSurfaceVariant, fontSize = 14.sp,
                        modifier = Modifier.padding(8.dp))
                }
                g.servers.forEach { sv ->
                    val k = Store.key(sv)
                    ServerRow(sv, st.pings[k], k == st.selectedKey) { onSelect(sv) }
                }
            }
        }
    }

    if (info && meta != null) {
        AlertDialog(
            onDismissRequest = { info = false },
            title = { Text(g.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    InfoLine("Ссылка", g.key)
                    InfoLine("Серверов", g.servers.size.toString())
                    meta.optLong("updated").takeIf { it > 0 }?.let { InfoLine("Обновлено", fmtDate(it)) }
                    if (meta.optBoolean("has_info")) {
                        val total = meta.optLong("total")
                        InfoLine("Трафик", "${fmtBytes(meta.optLong("used"))} / ${if (total > 0) fmtBytes(total) else "∞"}")
                    }
                    meta.optLong("expire").takeIf { it > 0 }?.let { InfoLine("Истекает", fmtDay(it)) }
                    meta.optString("support").takeIf { it.isNotBlank() }?.let { InfoLine("Поддержка", it) }
                }
            },
            confirmButton = { TextButton(onClick = { info = false }) { Text("Закрыть") } },
        )
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(if (g.url != null) "Удалить подписку?" else "Удалить все серверы из этого списка?") },
            text = { Text(g.title) },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Удалить", color = Bad) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun TrafficBar(used: Long, total: Long, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val frac = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    val shape = RoundedCornerShape(10.dp)
    Box(modifier.height(30.dp).clip(shape).border(1.dp, cs.outline, shape), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(cs.primary.copy(alpha = 0.28f)).align(Alignment.CenterStart))
        Text("${fmtBytes(used)}/${if (total > 0) fmtBytes(total) else "∞"}", fontSize = 13.sp, color = cs.onSurface, maxLines = 1)
    }
}

@Composable
fun GaugeIcon(tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        val w = 2.dp.toPx()
        drawArc(
            tint, startAngle = 160f, sweepAngle = 220f, useCenter = false,
            topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w),
            style = Stroke(width = w, cap = StrokeCap.Round),
        )
        drawLine(tint, center, Offset(size.width * 0.72f, size.height * 0.32f), strokeWidth = w, cap = StrokeCap.Round)
    }
}

@Composable
fun ConnectCard(st: AppState, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val accent = if (st.running) Ok else cs.primary
    val title = when {
        st.running -> "Подключено"
        st.connecting -> "Подключение…"
        else -> "Отключено"
    }
    val sv = st.selectedServer
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.18f), cs.surfaceVariant)))
            .padding(vertical = 28.dp, horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PowerButton(accent, st.connecting, onToggle)
        Spacer(Modifier.height(18.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = if (st.running) Ok else cs.onSurface)
        Spacer(Modifier.height(4.dp))
        Text(
            sv?.optString("name") ?: "Сервер не выбран",
            color = cs.onSurfaceVariant, fontSize = 14.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
        )
        st.error?.let {
            Text(it, color = Bad, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun PowerButton(accent: Color, connecting: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(accent, label = "accent")
    Box(Modifier.size(136.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(136.dp).clip(CircleShape).background(color.copy(alpha = 0.14f)))
        if (connecting) CircularProgressIndicator(Modifier.size(136.dp), color = color, strokeWidth = 3.dp)
        Box(
            Modifier.size(104.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(40.dp)) {
                val w = 4.dp.toPx()
                drawArc(
                    Color.White, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                    topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w),
                    style = Stroke(width = w, cap = StrokeCap.Round),
                )
                drawLine(
                    Color.White, Offset(size.width / 2, w / 2), Offset(size.width / 2, size.height * 0.5f),
                    strokeWidth = w, cap = StrokeCap.Round,
                )
            }
        }
    }
}

@Composable
fun ServerRow(sv: JSONObject, ping: Long?, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) cs.primaryContainer else cs.background)
            .border(if (selected) 1.5.dp else 0.dp, if (selected) cs.primary else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                sv.optString("name"), fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2,
                overflow = TextOverflow.Ellipsis, color = if (selected) cs.onPrimaryContainer else cs.onSurface,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${sv.optString("protocol")} · ${sv.optString("host")}:${sv.optInt("port")}",
                fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(12.dp))
        PingBadge(ping)
    }
}

@Composable
fun PingBadge(ms: Long?) {
    if (ms == null) return
    val (text, color) = when {
        ms < 0 -> "×" to Bad
        ms < 150 -> "$ms мс" to Ok
        ms < 400 -> "$ms мс" to Warn
        else -> "$ms мс" to Bad
    }
    Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}
