package app.obhod.client

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToLong

/** Кольцевой буфер логов sing-box и приложения. */
object LogStore {
    private val lines = ArrayDeque<String>()
    @Synchronized fun add(s: String) { lines.addLast(s); while (lines.size > 1000) lines.removeFirst() }
    @Synchronized fun text(): String = lines.joinToString("\n")
    @Synchronized fun clear() { lines.clear() }
}

/** ICMP-пинг через системную команду ping (root не нужен). Возвращает мс или -1. */
fun icmpPing(host: String, timeoutSec: Int): Long = runCatching {
    val p = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", timeoutSec.toString(), host)
        .redirectErrorStream(true).start()
    val out = p.inputStream.bufferedReader().readText()
    p.waitFor()
    Regex("time[=<]([0-9.]+)\\s*ms").find(out)?.groupValues?.get(1)?.toDouble()?.roundToLong()?.coerceAtLeast(1) ?: -1L
}.getOrDefault(-1L)

/** type: "tcp" (Rust, параллельно) или "icmp". */
suspend fun pingServers(list: List<JSONObject>, type: String, timeoutMs: Long): List<Long> =
    withContext(Dispatchers.IO) {
        if (type == "icmp") {
            val sem = Semaphore(16)
            val sec = ((timeoutMs + 999) / 1000).toInt().coerceAtLeast(1)
            coroutineScope {
                list.map { s -> async { sem.withPermit { icmpPing(s.optString("host"), sec) } } }.awaitAll()
            }
        } else runCatching { Core.pings(list, timeoutMs) }.getOrDefault(emptyList())
    }

class Traffic(val up: Long, val down: Long, val conns: Int)

/** Суммарный трафик и число соединений из Clash API ядра. */
fun fetchTraffic(port: Int, secret: String): Traffic? = runCatching {
    val c = URL("http://127.0.0.1:$port/connections").openConnection() as HttpURLConnection
    c.setRequestProperty("Authorization", "Bearer $secret")
    c.connectTimeout = 1500; c.readTimeout = 1500
    val o = JSONObject(c.inputStream.bufferedReader().readText())
    Traffic(o.optLong("uploadTotal"), o.optLong("downloadTotal"), o.optJSONArray("connections")?.length() ?: 0)
}.getOrNull()

fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    return String.format("%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60)
}
