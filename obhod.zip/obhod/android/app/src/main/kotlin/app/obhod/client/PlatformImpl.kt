package app.obhod.client

import android.net.ConnectivityManager
import android.net.IpPrefix
import android.net.Network
import android.os.Build
import android.util.Log
import io.nekohasekai.libbox.*
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface as JNetworkInterface

/** Реализация PlatformInterface из libbox (sing-box v1.10.x). */
class PlatformImpl(private val svc: ObhodVpnService) : PlatformInterface {
    private val cm = svc.getSystemService(ConnectivityManager::class.java)
    private var cb: ConnectivityManager.NetworkCallback? = null

    override fun usePlatformAutoDetectInterfaceControl() = true
    override fun autoDetectInterfaceControl(fd: Int) { svc.protect(fd) }

    override fun openTun(o: TunOptions): Int {
        val b = svc.Builder().setSession("Обход").setMtu(o.getMTU())
        o.getInet4Address().let { while (it.hasNext()) it.next().let { p -> b.addAddress(p.address(), p.prefix()) } }
        o.getInet6Address().let { while (it.hasNext()) it.next().let { p -> b.addAddress(p.address(), p.prefix()) } }
        b.addDnsServer(o.getDNSServerAddress().value)
        if (o.getAutoRoute()) { b.addRoute("0.0.0.0", 0); b.addRoute("::", 0) }
        if (Build.VERSION.SDK_INT >= 33) {
            for (iter in listOf(o.getInet4RouteExcludeAddress(), o.getInet6RouteExcludeAddress())) {
                while (iter.hasNext()) iter.next().let { p ->
                    runCatching { b.excludeRoute(IpPrefix(InetAddress.getByName(p.address()), p.prefix())) }
                }
            }
        }
        val inc = o.getIncludePackage(); val exc = o.getExcludePackage()
        var hasInclude = false
        while (inc.hasNext()) { runCatching { b.addAllowedApplication(inc.next()); hasInclude = true } }
        while (exc.hasNext()) runCatching { b.addDisallowedApplication(exc.next()) }
        if (!hasInclude) runCatching { b.addDisallowedApplication(svc.packageName) } // подписки/пинг мимо VPN
        val pfd = b.establish() ?: error("VPN-разрешение не выдано")
        svc.setTun(pfd)
        return pfd.detachFd()
    }

    override fun writeLog(message: String) { Log.d("sing-box", message); LogStore.add(message) }
    override fun useProcFS() = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    override fun findConnectionOwner(p: Int, src: String, sp: Int, dst: String, dp: Int): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) error("unsupported")
        return cm.getConnectionOwnerUid(p, InetSocketAddress(src, sp), InetSocketAddress(dst, dp))
    }
    override fun packageNameByUid(uid: Int): String =
        svc.packageManager.getPackagesForUid(uid)?.firstOrNull() ?: error("not found")
    override fun uidByPackageName(packageName: String): Int = svc.packageManager.getPackageUid(packageName, 0)

    override fun usePlatformDefaultInterfaceMonitor() = true
    override fun startDefaultInterfaceMonitor(l: InterfaceUpdateListener) {
        fun report(n: Network?) {
            val name = n?.let { cm.getLinkProperties(it)?.interfaceName } ?: return
            val idx = runCatching { JNetworkInterface.getByName(name).index }.getOrDefault(0)
            l.updateDefaultInterface(name, idx)
        }
        val c = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) = report(n)
            override fun onLinkPropertiesChanged(n: Network, lp: android.net.LinkProperties) = report(n)
            override fun onLost(n: Network) { l.updateDefaultInterface("", -1) }
        }
        cb = c; cm.registerDefaultNetworkCallback(c)
    }
    override fun closeDefaultInterfaceMonitor(l: InterfaceUpdateListener) {
        cb?.let { runCatching { cm.unregisterNetworkCallback(it) } }; cb = null
    }

    override fun usePlatformInterfaceGetter() = true
    override fun getInterfaces(): NetworkInterfaceIterator {
        val list = JNetworkInterface.getNetworkInterfaces().toList().map { ni ->
            NetworkInterface().apply {
                index = ni.index; mtu = ni.mtu; name = ni.name
                val addrs = ni.interfaceAddresses.map { "${it.address.hostAddress?.substringBefore('%')}/${it.networkPrefixLength}" }
                addresses = StrIter(addrs)
                var f = 0
                if (ni.isUp) f = f or 1
                if (ni.isLoopback) f = f or 4
                if (ni.isPointToPoint) f = f or 8
                if (ni.supportsMulticast()) f = f or 16
                flags = f
            }
        }
        return object : NetworkInterfaceIterator {
            private val it = list.iterator()
            override fun hasNext() = it.hasNext()
            override fun next(): NetworkInterface = it.next()
        }
    }

    override fun underNetworkExtension() = false
    override fun includeAllNetworks() = false
    override fun readWIFIState(): WIFIState? = null
    override fun clearDNSCache() {}
    override fun sendNotification(n: Notification) {}
}

class StrIter(private val l: List<String>) : StringIterator {
    private val it = l.iterator()
    override fun len() = l.size
    override fun hasNext() = it.hasNext()
    override fun next(): String = it.next()
}
