package app.obhod.client

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.SetupOptions

/** VPN-сервис: конфиг делает Rust-ядро, трафик обрабатывает sing-box (libbox). */
class ObhodVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var box: BoxService? = null

    fun setTun(p: ParcelFileDescriptor) { tun = p }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stop(); return START_NOT_STICKY }
        val store = Store(this)
        val server = store.selectedServer ?: return START_NOT_STICKY
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, notification())
        val config = Core.buildConfig(server.toString(), store.settings.toString())
        Thread {
            try {
                Libbox.setup(SetupOptions().also {
                    it.basePath = filesDir.path; it.workingPath = filesDir.path; it.tempPath = cacheDir.path
                    it.fixAndroidStack = Build.VERSION.SDK_INT in 31..33
                })
                box = Libbox.newService(config, PlatformImpl(this)).also { it.start() }
                running = true
            } catch (e: Throwable) {
                Log.e("obhod", "start failed", e); lastError = e.message; stop()
            }
        }.start()
        return START_STICKY
    }

    private fun stop() {
        runCatching { box?.close() }; box = null
        runCatching { tun?.close() }; tun = null
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() = stop()
    override fun onDestroy() { stop(); super.onDestroy() }

    private fun notification(): Notification {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        val stop = android.app.PendingIntent.getService(this, 0,
            Intent(this, ObhodVpnService::class.java).setAction(ACTION_STOP), android.app.PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "vpn").setContentTitle("Обход подключён")
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .addAction(Notification.Action.Builder(null, "Отключить", stop).build()).build()
    }

    companion object {
        const val ACTION_STOP = "app.obhod.STOP"
        @Volatile var running = false
        @Volatile var lastError: String? = null
    }
}
