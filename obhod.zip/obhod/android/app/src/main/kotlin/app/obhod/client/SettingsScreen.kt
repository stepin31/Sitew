package app.obhod.client

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

private val dnsPresets = listOf(
    "Cloudflare" to "https://1.1.1.1/dns-query",
    "Google" to "https://8.8.8.8/dns-query",
    "Quad9" to "https://9.9.9.9/dns-query",
    "AdGuard (блокировка рекламы)" to "https://dns.adguard-dns.com/dns-query",
)
private val themeModes = listOf("system", "dark", "light")
private val splitModes = listOf("off", "include", "exclude")
private val mtuValues = listOf(1400, 1500, 9000)
private val logLevels = listOf("error", "warn", "info", "debug")
private val ipPrefs = listOf("auto" to "Auto", "v4" to "IPv4", "v6" to "IPv6")

private typealias Upd = (JSONObject.() -> Unit) -> Unit

private fun JSONObject.strings(k: String): List<String> =
    optJSONArray(k)?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList()

@Composable
fun SettingsScreen(
    st: AppState,
    theme: String,
    onTheme: (String) -> Unit,
    onRefresh: () -> Unit,
    onClear: () -> Unit,
) {
    var page by rememberSaveable { mutableStateOf("main") }
    var s by remember { mutableStateOf(st.store.settings) }
    var autostart by remember { mutableStateOf(st.store.autostart) }
    val upd: Upd = { f -> st.store.edit(f); s = st.store.settings }
    BackHandler(enabled = page != "main") { page = "main" }

    when (page) {
        "vpn" -> VpnPage(s, upd) { page = "main" }
        "ping" -> PingPage(s, upd) { page = "main" }
        "stats" -> StatsPage(st) { page = "main" }
        "logs" -> LogsPage(s, upd) { page = "main" }
        else -> MainPage(
            st, theme, onTheme, onRefresh, onClear, s, upd, autostart,
            onAutostart = { autostart = it; st.store.autostart = it },
            onReset = { st.store.settings = JSONObject(); st.store.autostart = false; autostart = false; s = st.store.settings },
            open = { page = it },
        )
    }
}

@Composable
private fun MainPage(
    st: AppState, theme: String, onTheme: (String) -> Unit, onRefresh: () -> Unit, onClear: () -> Unit,
    s: JSONObject, upd: Upd, autostart: Boolean, onAutostart: (Boolean) -> Unit, onReset: () -> Unit, open: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val store = st.store
    var autoUpdate by remember { mutableStateOf(store.autoUpdate) }
    var dlg by remember { mutableStateOf<String?>(null) }
    val packages = s.strings("packages")
    val splitIdx = splitModes.indexOf(s.optString("split_mode", "off")).coerceAtLeast(0)
    val ipPref = s.optString("ip_pref", "auto")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text("Настройки", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)

        Section("Интерфейс") {
            Text("Тема оформления", Modifier.padding(start = 16.dp, top = 14.dp), fontSize = 16.sp, color = cs.onSurface)
            Segmented(listOf("Системная", "Тёмная", "Светлая"), themeModes.indexOf(theme).coerceAtLeast(0)) { onTheme(themeModes[it]) }
        }

        Section("Туннель") {
            SwitchRow("Россия напрямую", "Домены .ru, .su, .рф и локальная сеть идут мимо VPN", s.optBoolean("bypass_ru", true)) { upd { put("bypass_ru", it) } }
            Divider2()
            SettingRow("Всегда напрямую", domainsLabel(s.strings("direct_domains")), onClick = { dlg = "direct" })
            Divider2()
            SettingRow("Всегда через VPN", domainsLabel(s.strings("proxy_domains")), onClick = { dlg = "proxy" })
            Divider2()
            SwitchRow("Использовать Mux", "Мультиплексирование соединений (не работает с XTLS-flow)", s.optBoolean("mux", false)) { upd { put("mux", it) } }
            Divider2()
            SettingRow("Предпочтительный тип IP", ipPrefs.first { it.first == ipPref }.second, trailing = { Chevron() }, onClick = { dlg = "ip" })
        }

        Section("Прокси для выбранных приложений") {
            Segmented(listOf("Выкл", "Только выбранные", "Кроме выбранных"), splitIdx) { upd { put("split_mode", splitModes[it]) } }
            if (splitIdx != 0) {
                Divider2()
                SettingRow(
                    "Выбрать приложения",
                    if (packages.isEmpty()) "Ничего не выбрано — режим не применится" else "Выбрано: ${packages.size}",
                    trailing = { Chevron() }, onClick = { dlg = "apps" },
                )
            }
        }

        Section("Локальный прокси") {
            SwitchRow("Локальный SOCKS/HTTP-прокси", "Порт на этом устройстве для других приложений", s.optBoolean("local_proxy", false)) { upd { put("local_proxy", it) } }
            Divider2()
            SettingRow("Порт", s.optInt("local_port", 10808).toString(), onClick = { dlg = "port" })
            Divider2()
            SwitchRow("Разрешить подключения из LAN", "Прокси станет доступен другим устройствам в сети", s.optBoolean("allow_lan", false)) { upd { put("allow_lan", it) } }
        }

        Section("Подписки") {
            SwitchRow("Обновлять при запуске", "Обновляются подписки, у которых истёк интервал", autoUpdate) { autoUpdate = it; store.autoUpdate = it }
            Divider2()
            SettingRow(
                if (st.refreshing) "Обновление…" else "Обновить все подписки",
                "Подписок: ${st.groups.count { it.url != null }}. Каждой можно управлять на главном экране", onClick = onRefresh,
            )
            Divider2()
            SettingRow("Удалить все серверы", "Подписки и добавленные ссылки", titleColor = Bad, onClick = { dlg = "clear" })
        }

        Section("Расширенные настройки") {
            SettingRow("Настройки VPN", trailing = { Chevron() }, onClick = { open("vpn") })
            Divider2()
            SettingRow("Пинг", trailing = { Chevron() }, onClick = { open("ping") })
            Divider2()
            SwitchRow("Автозапуск приложения", "Подключаться после перезагрузки телефона", autostart, onAutostart)
            Divider2()
            SettingRow(
                "Kill Switch",
                "Откроет системные настройки VPN: включите «Постоянная VPN» и «Блокировать соединения без VPN»",
                onClick = { openVpnSettings(ctx) },
            )
        }

        Section("Другие настройки") {
            SettingRow("Статистика", trailing = { Chevron() }, onClick = { open("stats") })
            Divider2()
            SettingRow("Логи", trailing = { Chevron() }, onClick = { open("logs") })
            Divider2()
            SettingRow("Сброс настроек", "Вернуть значения по умолчанию (подписки останутся)", titleColor = Bad, onClick = { dlg = "reset" })
        }

        Section("О приложении") { SettingRow("Обход 0.4", "Ядро sing-box 1.10.7 · парсер подписок на Rust") }
        Spacer(Modifier.height(8.dp))
        Text(
            "Изменения применяются при следующем подключении.", Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 24.dp),
            fontSize = 12.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
        )
    }

    when (dlg) {
        "direct" -> ListEditDialog("Всегда напрямую", "Домены через пробел или с новой строки, например bank.ru", s.strings("direct_domains"),
            { l -> upd { put("direct_domains", JSONArray(l)) }; dlg = null }, { dlg = null })
        "proxy" -> ListEditDialog("Всегда через VPN", "Домены через пробел или с новой строки, например example.com", s.strings("proxy_domains"),
            { l -> upd { put("proxy_domains", JSONArray(l)) }; dlg = null }, { dlg = null })
        "apps" -> AppPickerDialog(packages.toSet(), { sel -> upd { put("packages", JSONArray(sel.toList())) }; dlg = null }, { dlg = null })
        "ip" -> ChoiceDialog("Предпочтительный тип IP", ipPrefs, ipPref, { v -> upd { put("ip_pref", v) }; dlg = null }, { dlg = null })
        "port" -> PortDialog(s.optInt("local_port", 10808), { p -> upd { put("local_port", p) }; dlg = null }, { dlg = null })
        "clear" -> ConfirmDialog("Удалить все серверы?", "Удалить", { dlg = null; onClear() }, { dlg = null })
        "reset" -> ConfirmDialog("Сбросить настройки?", "Сбросить", { dlg = null; onReset() }, { dlg = null })
    }
}

@Composable
private fun VpnPage(s: JSONObject, upd: Upd, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var dlg by remember { mutableStateOf<String?>(null) }
    val dns = s.optString("remote_dns", dnsPresets[0].second)
    val localDns = s.optBoolean("use_local_dns", false)
    val mode = s.optString("mode", "vpn")
    val excluded = s.strings("excluded_routes")

    SubPage("Настройки VPN", onBack) {
        Section("Настройки VPN") {
            SwitchRow("Использовать локальную DNS", "Запросы идут через системный DNS, а не через VPN-сервер", localDns) { upd { put("use_local_dns", it) } }
            Divider2()
            SettingRow(
                "DNS-сервер",
                if (localDns) "Не используется" else (dnsPresets.firstOrNull { it.second == dns }?.first ?: dns),
                trailing = { Chevron() }, onClick = { dlg = "dns" },
            )
            Divider2()
            SwitchRow("Анализ пакетов", "Определяет домены для правил маршрутизации", s.optBoolean("sniff", true)) { upd { put("sniff", it) } }
            Divider2()
            SettingRow(
                "Режим", if (mode == "proxy") "Прокси" else "VPN",
                trailing = { Chevron() }, onClick = { dlg = "mode" },
            )
            if (mode == "proxy") {
                Text(
                    "Без VPN: трафик идёт только через локальный SOCKS/HTTP-прокси на порту ${s.optInt("local_port", 10808)}",
                    Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp), fontSize = 13.sp, color = cs.onSurfaceVariant,
                )
            }
            Divider2()
            Text("MTU", Modifier.padding(start = 16.dp, top = 14.dp), fontSize = 16.sp, color = cs.onSurface)
            Segmented(mtuValues.map { it.toString() }, mtuValues.indexOf(s.optInt("mtu", 9000)).coerceAtLeast(0)) { upd { put("mtu", mtuValues[it]) } }
            Divider2()
            SettingRow(
                "Исключённые маршруты", if (excluded.isEmpty()) "Список пуст" else "Сетей: ${excluded.size}",
                trailing = { Chevron() }, onClick = { dlg = "routes" },
            )
        }
        Text(
            "Эти настройки не следует изменять, если вы полностью не понимаете их назначение.",
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp), fontSize = 13.sp, color = cs.onSurfaceVariant,
        )
        Section("Фоновые настройки") {
            SettingRow("Фоновая активность", trailing = { Chevron() }, onClick = {
                runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            })
        }
        Text(
            "Если система ограничивает фоновую активность, VPN может отключаться. Выберите для приложения режим «Без ограничений».",
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp), fontSize = 13.sp, color = cs.onSurfaceVariant,
        )
    }

    when (dlg) {
        "dns" -> DnsDialog(dns, { upd { put("remote_dns", it) }; dlg = null }, { dlg = null })
        "mode" -> ChoiceDialog("Режим", listOf("vpn" to "VPN", "proxy" to "Прокси"), mode, { v -> upd { put("mode", v) }; dlg = null }, { dlg = null })
        "routes" -> ListEditDialog("Исключённые маршруты", "Сети, которые пойдут мимо VPN: CIDR или IP, например 192.168.0.0/16 (Android 13+)", excluded,
            { l -> upd { put("excluded_routes", JSONArray(l)) }; dlg = null }, { dlg = null })
    }
}

@Composable
private fun PingPage(s: JSONObject, upd: Upd, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val type = s.optString("ping_type", "tcp")
    var t by remember { mutableFloatStateOf(s.optInt("ping_timeout", 5).toFloat()) }
    val display = if (s.optString("ping_display", "text") == "icon") 1 else 0

    SubPage("Пинг", onBack) {
        Section("Тип пинга") {
            RadioRow("TCP", "Время установки TCP-соединения с сервером", type == "tcp") { upd { put("ping_type", "tcp") } }
            Divider2()
            RadioRow("ICMP", "Системная команда ping (на части сетей блокируется)", type == "icmp") { upd { put("ping_type", "icmp") } }
        }
        Text(
            "Пинг через прокси (GET/HEAD) пока не поддерживается.",
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp), fontSize = 13.sp, color = cs.onSurfaceVariant,
        )
        Section("Тайм-аут пинга") {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text("${t.roundToInt()} сек", fontSize = 16.sp, color = cs.onSurface)
                Slider(
                    value = t, onValueChange = { t = it.roundToInt().toFloat() },
                    onValueChangeFinished = { upd { put("ping_timeout", t.roundToInt()) } },
                    valueRange = 1f..15f, steps = 13,
                )
                Row(Modifier.fillMaxWidth()) {
                    Text("1 сек", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    Text("15 сек", fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
            }
        }
        Section("Отображение результата") {
            Segmented(listOf("Текст", "Значок"), display) { upd { put("ping_display", if (it == 1) "icon" else "text") } }
        }
    }
}

@Composable
private fun StatsPage(st: AppState, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var traffic by remember { mutableStateOf<Traffic?>(null) }
    var upSpeed by remember { mutableLongStateOf(0L) }
    var downSpeed by remember { mutableLongStateOf(0L) }
    var tick by remember { mutableLongStateOf(0L) }

    LaunchedEffect(st.running) {
        var prev: Traffic? = null
        var prevAt = 0L
        while (st.running) {
            val tr = withContext(Dispatchers.IO) { fetchTraffic(ObhodVpnService.CLASH_PORT, ObhodVpnService.clashSecret) }
            val now = System.currentTimeMillis()
            val p = prev
            if (tr != null && p != null && now > prevAt) {
                val dt = (now - prevAt) / 1000.0
                upSpeed = ((tr.up - p.up) / dt).toLong().coerceAtLeast(0)
                downSpeed = ((tr.down - p.down) / dt).toLong().coerceAtLeast(0)
            }
            traffic = tr; prev = tr; prevAt = now; tick = now
            delay(1000)
        }
        traffic = null; upSpeed = 0; downSpeed = 0
    }

    SubPage("Статистика", onBack) {
        if (!st.running) {
            Text("Подключитесь к VPN, чтобы увидеть статистику.", Modifier.padding(vertical = 24.dp), color = cs.onSurfaceVariant)
        } else {
            val tr = traffic
            Section("Трафик за сессию") {
                SettingRow("Скачано", tr?.let { fmtBytes(it.down) } ?: "—", trailing = { Text("${fmtBytes(downSpeed)}/с", color = cs.primary) })
                Divider2()
                SettingRow("Отправлено", tr?.let { fmtBytes(it.up) } ?: "—", trailing = { Text("${fmtBytes(upSpeed)}/с", color = cs.primary) })
            }
            Section("Соединение") {
                SettingRow("Активных соединений", tr?.conns?.toString() ?: "—")
                Divider2()
                val started = ObhodVpnService.startedAt
                SettingRow("Время работы", if (started > 0 && tick > 0) fmtDuration(tick - started) else "—")
            }
        }
    }
}

@Composable
private fun LogsPage(s: JSONObject, upd: Upd, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(LogStore.text()) }
    LaunchedEffect(Unit) { while (true) { text = LogStore.text(); delay(1000) } }
    val level = logLevels.indexOf(s.optString("log_level", "warn")).coerceAtLeast(0)

    SubPage("Логи", onBack, scroll = false) {
        Segmented(logLevels, level) { upd { put("log_level", logLevels[it]) } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                clip.setText(AnnotatedString(text))
                android.widget.Toast.makeText(ctx, "Скопировано", android.widget.Toast.LENGTH_SHORT).show()
            }) { Text("Копировать") }
            OutlinedButton(onClick = { LogStore.clear(); text = "" }) { Text("Очистить") }
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant)
                .verticalScroll(rememberScrollState(), reverseScrolling = true),
        ) {
            Text(
                if (text.isBlank()) "Логи пусты. Уровень логов применяется при следующем подключении." else text,
                Modifier.padding(12.dp), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cs.onSurface,
            )
        }
        Spacer(Modifier.height(12.dp))
    }
}

private fun domainsLabel(l: List<String>) = if (l.isEmpty()) "Список пуст" else l.joinToString(", ")

private fun openVpnSettings(ctx: Context) {
    runCatching { ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
private fun SubPage(title: String, onBack: () -> Unit, scroll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад") }
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(
            Modifier.weight(1f).fillMaxWidth()
                .then(if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(horizontal = 20.dp),
            content = content,
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        title.uppercase(), color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 8.dp, top = 22.dp, bottom = 8.dp),
    )
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant), content = content)
}

@Composable
private fun Divider2() {
    HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun Chevron() {
    Icon(Icons.Rounded.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    titleColor: Color = Color.Unspecified,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = if (titleColor == Color.Unspecified) cs.onSurface else titleColor,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        trailing?.invoke()
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    SettingRow(title, subtitle, trailing = { Switch(checked = checked, onCheckedChange = onChange) }, onClick = { onChange(!checked) })
}

@Composable
private fun RadioRow(title: String, subtitle: String?, selected: Boolean, onClick: () -> Unit) {
    SettingRow(title, subtitle, trailing = { RadioButton(selected = selected, onClick = null) }, onClick = onClick)
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(14.dp)).background(cs.background).padding(4.dp),
    ) {
        options.forEachIndexed { i, t ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                    .background(if (sel) cs.primary else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    t, color = if (sel) cs.onPrimary else cs.onSurfaceVariant, fontSize = 13.sp,
                    fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun ConfirmDialog(title: String, action: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(action, color = Bad) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun ChoiceDialog(title: String, options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                options.forEach { (v, label) ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(v) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = current == v, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun PortDialog(current: Int, onSave: (Int) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(current.toString()) }
    val port = text.toIntOrNull()
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Порт локального прокси") },
        text = {
            OutlinedTextField(
                text, { text = it.filter { c -> c.isDigit() }.take(5) }, singleLine = true,
                label = { Text("1024–65535") }, isError = port == null || port !in 1024..65535,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = { TextButton(onClick = { if (port != null && port in 1024..65535) onSave(port) }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun ListEditDialog(title: String, hint: String, initial: List<String>, onSave: (List<String>) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial.joinToString("\n")) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                Text(hint, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text.split(Regex("[\\s,;]+")).map { it.trim() }.filter { it.isNotEmpty() }) }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun DnsDialog(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var custom by remember { mutableStateOf(if (dnsPresets.any { it.second == current }) "" else current) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("DNS-сервер") },
        text = {
            Column {
                dnsPresets.forEach { (name, url) ->
                    Row(Modifier.fillMaxWidth().clickable { onSave(url) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = current == url, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(name, fontSize = 15.sp)
                            Text(url, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                OutlinedTextField(
                    custom, { custom = it }, label = { Text("Свой (https://… или IP)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        },
        confirmButton = { TextButton(onClick = { if (custom.isNotBlank()) onSave(custom.trim()) }) { Text("Применить свой") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
