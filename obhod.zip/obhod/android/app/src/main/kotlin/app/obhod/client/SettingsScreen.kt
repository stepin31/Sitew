package app.obhod.client

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val dnsPresets = listOf(
    "Cloudflare" to "https://1.1.1.1/dns-query",
    "Google" to "https://8.8.8.8/dns-query",
    "Quad9" to "https://9.9.9.9/dns-query",
    "AdGuard (блокировка рекламы)" to "https://dns.adguard-dns.com/dns-query",
)
private val themeModes = listOf("system", "dark", "light")
private val splitModes = listOf("off", "include", "exclude")
private val mtuValues = listOf(1400, 1500, 9000)

private fun JSONObject.strings(k: String): List<String> =
    optJSONArray(k)?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList()

@Composable
fun SettingsScreen(
    st: AppState,
    theme: String,
    onTheme: (String) -> Unit,
    onRefresh: () -> Unit,
    onClear: () -> Unit,
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val store = st.store
    var s by remember { mutableStateOf(store.settings) }
    var autoUpdate by remember { mutableStateOf(store.autoUpdate) }
    var dlg by remember { mutableStateOf<String?>(null) }
    fun upd(f: JSONObject.() -> Unit) { store.edit(f); s = store.settings }

    val dns = s.optString("remote_dns", dnsPresets[0].second)
    val packages = s.strings("packages")
    val splitIdx = splitModes.indexOf(s.optString("split_mode", "off")).coerceAtLeast(0)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text("Настройки", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)

        Section("Тема") {
            Segmented(listOf("Системная", "Тёмная", "Светлая"), themeModes.indexOf(theme).coerceAtLeast(0)) { onTheme(themeModes[it]) }
        }

        Section("Подписки") {
            SwitchRow("Обновлять при запуске", "Список серверов обновится при открытии приложения", autoUpdate) {
                autoUpdate = it; store.autoUpdate = it
            }
            Divider2()
            SettingRow(
                if (st.refreshing) "Обновление…" else "Обновить все подписки",
                "Подписок: ${st.groups.count { it.url != null }}. Каждой можно управлять на главном экране", onClick = onRefresh,
            )
            Divider2()
            SettingRow("Удалить все серверы", "Подписки и добавленные ссылки", titleColor = Bad, onClick = { dlg = "clear" })
        }

        Section("Маршрутизация") {
            SwitchRow("Россия напрямую", "Домены .ru, .su, .рф и локальная сеть идут мимо VPN", s.optBoolean("bypass_ru", true)) {
                upd { put("bypass_ru", it) }
            }
            Divider2()
            SettingRow("Всегда напрямую", domainsLabel(s.strings("direct_domains")), onClick = { dlg = "direct" })
            Divider2()
            SettingRow("Всегда через VPN", domainsLabel(s.strings("proxy_domains")), onClick = { dlg = "proxy" })
        }

        Section("Раздельное туннелирование") {
            Segmented(listOf("Выкл", "Только выбранные", "Кроме выбранных"), splitIdx) { upd { put("split_mode", splitModes[it]) } }
            if (splitIdx != 0) {
                Divider2()
                SettingRow(
                    "Выбрать приложения",
                    if (packages.isEmpty()) "Ничего не выбрано — режим не применится" else "Выбрано: ${packages.size}",
                    onClick = { dlg = "apps" },
                )
            }
        }

        Section("DNS и сеть") {
            SettingRow("DNS-сервер", dnsPresets.firstOrNull { it.second == dns }?.first ?: dns, onClick = { dlg = "dns" })
            Divider2()
            Text("MTU", Modifier.padding(start = 16.dp, top = 14.dp), fontSize = 16.sp, color = cs.onSurface)
            Segmented(mtuValues.map { it.toString() }, mtuValues.indexOf(s.optInt("mtu", 9000)).coerceAtLeast(0)) {
                upd { put("mtu", mtuValues[it]) }
            }
        }

        Section("Безопасность") {
            SettingRow(
                "Kill Switch",
                "Откроет системные настройки VPN: включите «Постоянная VPN» и «Блокировать соединения без VPN»",
                onClick = { openVpnSettings(ctx) },
            )
        }

        Section("О приложении") {
            SettingRow("Обход 0.2", "Ядро sing-box 1.10.7 · парсер подписок на Rust")
        }

        Text(
            "Изменения применяются при следующем подключении.", Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 24.dp),
            fontSize = 12.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
        )
    }

    when (dlg) {
        "dns" -> DnsDialog(dns, { upd { put("remote_dns", it) }; dlg = null }, { dlg = null })
        "direct" -> ListEditDialog("Всегда напрямую", "Домены через пробел или с новой строки, например bank.ru", s.strings("direct_domains"),
            { l -> upd { put("direct_domains", JSONArray(l)) }; dlg = null }, { dlg = null })
        "proxy" -> ListEditDialog("Всегда через VPN", "Домены через пробел или с новой строки, например example.com", s.strings("proxy_domains"),
            { l -> upd { put("proxy_domains", JSONArray(l)) }; dlg = null }, { dlg = null })
        "apps" -> AppPickerDialog(packages.toSet(), { sel -> upd { put("packages", JSONArray(sel.toList())) }; dlg = null }, { dlg = null })
        "clear" -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Удалить все серверы?") },
            confirmButton = { TextButton(onClick = { dlg = null; onClear() }) { Text("Удалить", color = Bad) } },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Отмена") } },
        )
    }
}

private fun domainsLabel(l: List<String>) = if (l.isEmpty()) "Список пуст" else l.joinToString(", ")

private fun openVpnSettings(ctx: Context) {
    runCatching { ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        title.uppercase(), color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 8.dp, top = 22.dp, bottom = 8.dp),
    )
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant), content = content)
}

@Composable
private fun Divider2() {
    HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    titleColor: Color = Color.Unspecified,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = if (titleColor == Color.Unspecified) cs.onSurface else titleColor,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        trailing?.invoke()
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    SettingRow(title, subtitle, trailing = { Switch(checked = checked, onCheckedChange = onChange) }, onClick = { onChange(!checked) })
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(14.dp)).background(cs.background).padding(4.dp),
    ) {
        options.forEachIndexed { i, t ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                    .background(if (sel) cs.primary else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    t, color = if (sel) cs.onPrimary else cs.onSurfaceVariant, fontSize = 13.sp,
                    fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun ListEditDialog(title: String, hint: String, initial: List<String>, onSave: (List<String>) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial.joinToString("\n")) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                Text(hint, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text.split(Regex("[\\s,;]+")).map { it.trim() }.filter { it.isNotEmpty() }) }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun DnsDialog(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var custom by remember { mutableStateOf(if (dnsPresets.any { it.second == current }) "" else current) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("DNS-сервер") },
        text = {
            Column {
                dnsPresets.forEach { (name, url) ->
                    Row(Modifier.fillMaxWidth().clickable { onSave(url) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = current == url, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(name, fontSize = 15.sp)
                            Text(url, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                OutlinedTextField(
                    custom, { custom = it }, label = { Text("Свой (https://… или IP)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        },
        confirmButton = { TextButton(onClick = { if (custom.isNotBlank()) onSave(custom.trim()) }) { Text("Применить свой") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
