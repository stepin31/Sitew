package app.obhod.client

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

/** Автоподключение после перезагрузки (если включено и разрешение VPN уже выдано). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Store(ctx).autostart) return
        if (VpnService.prepare(ctx) != null) return
        runCatching { ctx.startForegroundService(Intent(ctx, ObhodVpnService::class.java)) }
    }
}
