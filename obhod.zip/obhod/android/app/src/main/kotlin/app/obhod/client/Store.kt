package app.obhod.client

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Подписки, выбранный сервер и настройки (SharedPreferences). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("obhod", Context.MODE_PRIVATE)

    var subscriptions: List<String>
        get() = JSONArray(p.getString("subs", "[]")).let { a -> List(a.length()) { a.getString(it) } }
        set(v) = p.edit().putString("subs", JSONArray(v).toString()).apply()

    var servers: List<JSONObject>
        get() = JSONArray(p.getString("servers", "[]")).let { a -> List(a.length()) { a.getJSONObject(it) } }
        set(v) = p.edit().putString("servers", JSONArray(v).toString()).apply()

    var selected: Int
        get() = p.getInt("selected", 0)
        set(v) = p.edit().putInt("selected", v).apply()

    /** Настройки совпадают по полям с Settings в Rust (config.rs). */
    var settings: JSONObject
        get() = JSONObject(p.getString("settings", "{}"))
        set(v) = p.edit().putString("settings", v.toString()).apply()

    /** Загружает подписку; User-Agent как у v2ray-клиентов, чтобы панели отдали список ссылок. */
    fun fetch(url: String): List<JSONObject> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "v2rayNG/1.8")
        c.connectTimeout = 15000; c.readTimeout = 15000
        val body = c.inputStream.bufferedReader().readText()
        return Core.servers(body)
    }

    fun addInput(text: String): Int {
        val t = text.trim()
        val found = if (t.startsWith("http")) {
            subscriptions = (subscriptions + t).distinct(); fetch(t)
        } else Core.servers(t)
        servers = (servers + found).distinctBy { it.getString("host") + it.getInt("port") + it.getString("protocol") }
        return found.size
    }

    fun refreshAll() { servers = subscriptions.flatMap { runCatching { fetch(it) }.getOrDefault(emptyList()) } }
}
