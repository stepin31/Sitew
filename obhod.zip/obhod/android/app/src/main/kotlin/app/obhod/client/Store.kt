package app.obhod.client

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Блок серверов: подписка (url != null) или «добавлено вручную». offset — позиция в общем списке. */
class SubGroup(
    val key: String,
    val title: String,
    val url: String?,
    val meta: JSONObject?,
    val servers: List<JSONObject>,
)

/**
 * Подписки, серверы и настройки (SharedPreferences).
 * Подписка хранится как JSON: url, title, updated, used, total, expire, has_info, support, announce, interval, servers[].
 * Поля settings совпадают с Settings в Rust (config.rs).
 */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("obhod", Context.MODE_PRIVATE)

    init { // миграция с версии 0.1/0.2: подписки были списком ссылок
        if (!p.contains("subs2")) {
            val urls = JSONArray(p.getString("subs", "[]")).let { a -> List(a.length()) { a.getString(it) } }
            val old = if (p.contains("from_subs")) readObjs("from_subs") else readObjs("servers")
            writeObjs("subs2", urls.mapIndexed { i, u ->
                JSONObject().put("url", u).put("updated", 0L)
                    .put("servers", JSONArray(if (i == 0) old else emptyList<JSONObject>()))
            })
        }
    }

    private fun readObjs(key: String): List<JSONObject> =
        JSONArray(p.getString(key, "[]")).let { a -> List(a.length()) { a.getJSONObject(it) } }

    private fun writeObjs(key: String, v: List<JSONObject>) =
        p.edit().putString(key, JSONArray(v).toString()).apply()

    private var manual: List<JSONObject>
        get() = readObjs("manual")
        set(v) = writeObjs("manual", v)

    private var subs: List<JSONObject>
        get() = readObjs("subs2")
        set(v) = writeObjs("subs2", v)

    val subscriptionCount: Int get() = subs.size

    private fun JSONObject.serverList(): List<JSONObject> =
        optJSONArray("servers")?.let { a -> List(a.length()) { a.getJSONObject(it) } } ?: emptyList()

    fun groups(): List<SubGroup> {
        val out = mutableListOf<SubGroup>()
        for (s in subs) {
            val url = s.getString("url")
            val title = s.optString("title").ifBlank { runCatching { java.net.URI(url).host }.getOrNull() ?: url }
            out += SubGroup(url, title, url, s, s.serverList())
        }
        val m = manual
        if (m.isNotEmpty()) out += SubGroup("manual", "Добавлено вручную", null, null, m)
        return out
    }

    val servers: List<JSONObject> get() = groups().flatMap { it.servers }

    var selectedKey: String?
        get() = p.getString("selected_key", null)
        set(v) = p.edit().putString("selected_key", v).apply()

    val selectedServer: JSONObject?
        get() = servers.let { l -> l.firstOrNull { key(it) == selectedKey } ?: l.firstOrNull() }

    var collapsed: Set<String>
        get() = p.getStringSet("collapsed", emptySet())?.toSet() ?: emptySet()
        set(v) = p.edit().putStringSet("collapsed", v).apply()

    var settings: JSONObject
        get() = JSONObject(p.getString("settings", "{}"))
        set(v) = p.edit().putString("settings", v.toString()).apply()

    fun edit(block: JSONObject.() -> Unit) { val s = settings; s.block(); settings = s }

    var theme: String
        get() = p.getString("theme", "system") ?: "system"
        set(v) = p.edit().putString("theme", v).apply()

    var autoUpdate: Boolean
        get() = p.getBoolean("auto_update", true)
        set(v) = p.edit().putBoolean("auto_update", v).apply()

    private fun header(c: HttpURLConnection, name: String): String? {
        val raw = c.getHeaderField(name)?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return runCatching {
            when {
                raw.startsWith("base64:") -> String(Base64.decode(raw.removePrefix("base64:"), Base64.DEFAULT), Charsets.UTF_8)
                raw.contains('%') -> URLDecoder.decode(raw, "UTF-8")
                else -> raw
            }
        }.getOrDefault(raw)
    }

    /** Загружает подписку вместе со служебными заголовками (название, трафик, срок, поддержка, объявление). */
    fun fetchSub(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "v2rayNG/1.8")
        c.connectTimeout = 15000; c.readTimeout = 15000
        val body = c.inputStream.bufferedReader().readText()
        val o = JSONObject()
        o.put("url", url)
        o.put("title", header(c, "profile-title") ?: "")
        o.put("support", header(c, "support-url") ?: header(c, "profile-web-page-url") ?: "")
        o.put("announce", header(c, "announce") ?: "")
        o.put("interval", header(c, "profile-update-interval")?.trim()?.toIntOrNull() ?: 0)
        header(c, "subscription-userinfo")?.let { h ->
            var up = 0L; var down = 0L
            for (m in Regex("(upload|download|total|expire)=(\\d+)").findAll(h)) {
                val n = m.groupValues[2].toLongOrNull() ?: continue
                when (m.groupValues[1]) {
                    "upload" -> up = n
                    "download" -> down = n
                    "total" -> o.put("total", n)
                    "expire" -> o.put("expire", n)
                }
            }
            o.put("used", up + down)
            o.put("has_info", true)
        }
        o.put("updated", System.currentTimeMillis())
        o.put("servers", JSONArray(Core.servers(body)))
        return o
    }

    /** Ссылка подписки (http…) или одна/несколько ссылок серверов. Возвращает число найденных серверов. */
    fun addInput(text: String): Int {
        val t = text.trim()
        return if (t.startsWith("http")) {
            val o = fetchSub(t)
            subs = subs.filter { it.getString("url") != t } + o
            o.serverList().size
        } else {
            val f = Core.servers(t)
            manual = (manual + f).distinctBy { key(it) }
            f.size
        }
    }

    fun refreshSub(url: String) {
        val o = fetchSub(url)
        subs = subs.map { if (it.getString("url") == url) o else it }
    }

    /** Обновляет подписки (onlyDue — только те, у кого истёк интервал). Возвращает число успешных. */
    fun refreshAll(onlyDue: Boolean = false): Int {
        var ok = 0
        for (s in subs) {
            val h = s.optInt("interval").let { if (it > 0) it else 24 }
            val due = !onlyDue || s.serverList().isEmpty() ||
                System.currentTimeMillis() - s.optLong("updated") > h * 3_600_000L
            if (due) runCatching { refreshSub(s.getString("url")); ok++ }
        }
        return ok
    }

    fun removeSubscription(url: String) { subs = subs.filter { it.getString("url") != url } }
    fun clearManual() { manual = emptyList() }
    fun clearServers() { subs = emptyList(); manual = emptyList(); selectedKey = null }

    companion object {
        fun key(s: JSONObject): String = s.optString("name") + "|" + s.optString("host") + ":" + s.optInt("port")
    }
}
