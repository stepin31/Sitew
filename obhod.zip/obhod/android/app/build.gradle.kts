plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "app.obhod.client"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.obhod.client"
        minSdk = 24; targetSdk = 34; versionCode = 2; versionName = "0.2"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") }
    }
    buildFeatures { compose = true }
    sourceSets["main"].jniLibs.srcDir("src/main/jniLibs") // сюда кладёт .so скрипт build-rust.sh
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("org.json:json:20240303")
    implementation(files("libs/libbox.aar")) // ядро sing-box: см. README
}
